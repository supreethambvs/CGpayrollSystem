package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	PayrollServicesImpl payrollServicesImpl = new PayrollServicesImpl();
	
	
	public static void main (String[] args) {
		int associateIdToBeSearch = 299;
		Associate associate = searchAssociate("BVS");
		if(associate!=null)
		System.out.println(associate.getFirstname()+" "+associate.getLastname());
		else
		System.out.println("IsNotFound");
	}
	public static Associate searchAssociate(String Name){	
	Associate[] associates = new Associate[3];
	associates[0] = new Associate(221,3334,"PREETHAM","SHARMA","EE","MF","HDFRH","BVS@GMAIL.COM",new Salary(2323,3456,5000,600,4509,600,450,6709,560,600,450),new BankDetails(2345,"BVS","SDFG"));
	associates[1] = new Associate(221,3334,"BVS","PREETHAM","EE","MF","HDFRH","SBVS@GMAIL.COM",new Salary(2323,3456,5000,600,4509,600,450,6709,560,600,450),new BankDetails(2345,"BSV","SDFG"));
	associates[2] = new Associate(223,333,"SUP","BVS","EEE","JAVA","JJJJJ","SBVS@GMAIL.COM",new Salary(3456,450,6790,4500,4567,8900,560,4500,230,456,6000),new BankDetails(2345,"HDFC","HGFD"));
	BankDetails bank = new BankDetails(1111111, "SBI", "HDBF");
	Salary sal  = new Salary(1000000, 456, 4567, 7890, 678, 1222, 222, 222, 2222, 22, 22222222);
	for(Associate associate:associates){
		if(associate!=null&&associate.getFirstname()==Name&&associate.getYearlyInvestmentUnder80C()>1500&&associate.getSalary().getBasicSalary()<=30000)
			return associate;
	}
	return null;
	}
	

}
