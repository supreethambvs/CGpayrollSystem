package com.cg.payroll.main;

import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass1 {
	public static void main(String[] args) {
		PayrollServicesImpl payrollServicesImpl = new PayrollServicesImpl();
		int associateId = payrollServicesImpl.acceptAssociateDetails("PREETHAM","BVS","BVS@GMAIL.COM","SE","A4","HHHH",100000f,100000f,1000f,1000f,22222,"SBI","AAAA");
		System.out.println(associateId);
		float netSalary=payrollServicesImpl.calculateNetSalary(associateId);
		System.out.println(netSalary);
		System.out.println(payrollServicesImpl.getAssociateDetails(associateId).getSalary().getMonthlyTax());
	}

}

